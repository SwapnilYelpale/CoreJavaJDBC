package com.jlt.main;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class EmployeeDelete {
	public static void main(String[] args) {
		String url="jdbc:sqlserver://localhost:1433;databasename=employeedb;integratedSecurity=true;";
        String username="";
        String password="";
        String 
        try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection connection=DriverManager.getConnection(url, username, password);
			PreparedStatement preparedstatement=connection.preparedstatement(sql_Delete);
			preparedstatement.setInt(1, 1000);
			int rowCount=preparedstatement.executeDelete();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}

}
