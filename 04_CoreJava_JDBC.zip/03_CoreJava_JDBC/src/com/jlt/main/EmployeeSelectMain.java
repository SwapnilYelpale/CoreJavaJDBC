package com.jlt.main;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class EmployeeSelectMain {
	
	public static void main(String[] args) {
		
	String url="jdbc:sqlserver://localhost:1433;databasename=employeedb;integratedSecurity=true;";
	String username="";
	String password="";
	String sql_select="select*from employee_master";
		try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection connection=DriverManager.getConnection(url,username,password);
		PreparedStatement prepareStatement = connection.prepareStatement(sql_select);
		ResultSet resultSet=prepareStatement.executeQuery();
		
		while(resultSet.next()) {
			resultSet.getInt("employee_id");
			resultSet.getString("name");
			resultSet.getFloat("salary");
			
			System.out.println(resultSet.getInt("employeeid"));
			System.out.println(resultSet.getString("name"));
			System.out.println(resultSet.getFloat("salary"));
		}
		connection.close();
	} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
	}
	

}
}