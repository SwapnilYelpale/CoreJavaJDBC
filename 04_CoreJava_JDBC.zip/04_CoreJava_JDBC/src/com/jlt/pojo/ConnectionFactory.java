package com.jlt.pojo;
import  java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConnectionFactory {
	
	private String url="jdbc:sqlserver://localhost:1433;databasename=employeedb;integratedSecurity=true;";
	private Connection connection;
	
	public Connection getDBConnection() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection =DriverManager.getConnection(url);
			return connection;
		}catch (ClassNotFoundException | SQLException e)
		{
			System.out.println("Exception::"+e.getMessage());
		}
		return null;
	}


}
