package com.jlt.main;
import java.util.Scanner;
import com.jlt.dao.EmployeeDao;
import com.jlt.pojo.Employee;
public class EmployeeCRUDMain {
	public static void main(String[] args) {
		
		int employeeid;
		String name;
		double salary;
		int choice;
		String continueChoice="";
		
		Scanner scanner =new Scanner (System.in);
		EmployeeDao employeeDao=new EmployeeDao();
		
		do {
			System.out.println("Menu");
			System.out.println("1 Add new Employee");
			switch(choice) {
			case 1:
				System.out.println("Enter EmployeeId");
				int employeeId= scanner.nextInt();
				System.out.println("Enter Name");
				String Name=scanner.next();
				System.out.println("Enter salary");
				Double Salary=scanner.nextDouble();
				
				Employee employee =new Employee(employeeId,Name,Salary);
				
				if(employeeDao.addEmployee(employee))
				{
					System.out.println("employee Added successfully");
					}
				else {
					System.out.println("failed to add emplpoyee");
				}
				break;
				
			}
		}
	}

}
