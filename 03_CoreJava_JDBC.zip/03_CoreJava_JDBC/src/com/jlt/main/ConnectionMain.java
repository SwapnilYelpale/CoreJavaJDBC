package com.jlt.main;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class ConnectionMain {
	public static void main(String[] args) {
		String url="jdbc:sqlserver://localhost:1433;databasename=employeedb;integratedSecurity=true;";
		String username="";
		String password="";
		String sql_insert="insert into employee_master values(???)";
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println(" 1 Driver loaded successfully");
			Connection connection=DriverManager.getConnection(url,username,password);
			System.out.println("2 connection success");
			PreparedStatement preparedStatement =connection.prepareStatement(sql_insert);
			preparedStatement.setInt(1,101);
			preparedStatement.setString(2,"Neel");
			preparedStatement.setFloat(3,(float)1000.0);
			System.out.println("prepared statement created;");
			
			int rowCount=preparedStatement.executeUpdate();
			System.out.println(rowCount + "Record inserted");
			connection.close();
			System.out.println("3 connection closed");

		} catch (ClassNotFoundException | SQLException e) {
			
			System.out.println("Exception::"+e.getMessage());
			e.printStackTrace();
		}

	}
}
