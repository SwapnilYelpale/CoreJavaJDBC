package com.jlt.main;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmployeeUpdate {
public static void main(String[] args) {
	String url="jdbc:sqlserver://localhost:1433;databasename=employeedb;integratedSecurity=true;";
	String username="";
	String password=""	;	
	String sql_update="update employee_master set salary=? where employee_id=?";
	
	try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection connection=DriverManager.getConnection(url,username,password);
		PreparedStatement prepareStatement =connection.prepareStatement(sql_update);
		prepareStatement.setFloat(1, 1000);
		prepareStatement.setInt(2, 2000);
		
		int rowCount =prepareStatement.executeUpdate();
		System.out.println(rowCount +"records updated successfully");
		connection.close();
		
	} catch (ClassNotFoundException | SQLException e) {
		e.printStackTrace();
	}
}
}
